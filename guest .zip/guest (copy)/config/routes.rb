Rails.application.routes.draw do
	get '/users/caution'
  get 'admins/new'
  get 'sessions/new'
  get 'users/index'
  get '/admins/index'
  get '/users/signin/:date' , to: 'users#new'
  post '/users/signin/:date' , to: 'users#create'
   post '/admins/index', to: 'admins#create'
   get '/admins/show/:id', to: 'admins#show'
   get '/admins/show/:id', to: 'admins#show'
  post '/users/index', to: 'sessions#create'
 

get 'users/after_signin'

  get 'signs/after_index'
  get '/signs/new/:id', to: 'signs#new'
  post '/signs/new/:id', to: 'signs#update'
  patch '/signs/update/:id', to: 'signs#update'

  get 'signs/after_new'




  get    '/login',   to: 'sessions#new'
  post   '/login',   to: 'sessions#create'
  delete '/logout',  to: 'sessions#destroy'

  get '/alogin', to: 'sessions#new_admin'
  post 'alogin', to: 'sessions#create_admin'
  delete '/alogout', to: 'sessions#destroy_admin'



  get '/sessions/show/:id', to: 'sessions#show'

get "/admins/edit/:id", to: "admins#edit"
  patch "/admins/update/:id", to: "admins#update", as: 'admin_update'

  get '/sessions/show/signs/cancel/:id', to: "signs#destroy"
  get '/signs/afterdelete'


get '/admins/newbook', to: "admins#newbook"
post '/admins/newbook', to: "admins#newbooking", as: 'newbooking'

post '/sessions/show/:id' , to: "signs#destroy"




  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
