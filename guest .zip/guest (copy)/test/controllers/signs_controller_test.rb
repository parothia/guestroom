require 'test_helper'

class SignsControllerTest < ActionDispatch::IntegrationTest
  test "should get index" do
    get signs_index_url
    assert_response :success
  end

end
