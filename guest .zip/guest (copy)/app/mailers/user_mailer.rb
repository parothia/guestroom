class UserMailer < ApplicationMailer
	default from: 'notify@example.com'

	def welcome_email(sign)
		@sign = sign
		@sum= 'http://localhost:3000/signs/new/'+ @sign.id.to_s
		@url = @sum
		mail(to: @sign.email,subject: 'Welcome to Room Booking of NITC')
	end


	def confirm_email(id)
		@id = id
		mail(to: id.email,subject: 'Confirmation Mail from NITC ')
	end

	def update_email(sign)
		@sign = sign
		mail(to: sign.email,subject: 'Updation Mail from NITC ')
	end



end
