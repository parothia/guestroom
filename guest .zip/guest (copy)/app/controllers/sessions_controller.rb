class SessionsController < ApplicationController
  add_flash_types :success, :warning, :danger, :info
  def new
  end

  def create
  temp={name: params[:name], email: params[:email]}
  @user = User.find_by(temp)
  if @user.present?
    @id =log_in @user
    redirect_to '/sessions/show/'+@id.to_s
  else
  	flash[:danger] = "Name or email is incorrect"
    redirect_to '/users/index' 
  end
  end

  def show
    @usid = User.find_by(id: params[:id])
  end

  def update
  end

   def destroy
    log_out
    redirect_to '/users/index'
  end




def new_admin
  end


def create_admin
  temp={name: params[:name], password: params[:password]}
  @admin = Admin.find_by(temp)
  if @admin.present?
    @id = alog_in @admin
    debugger
    redirect_to '/admins/show/'+@id.to_s
  else
    flash[:danger] = "Invalid Name/password Combination"
    redirect_to '/users/index' 
  end
  end


  def show_admin
    @adid = Admin.find_by(id: params[:id])
  end


  def destroy_admin
    alog_out
    redirect_to '/users/index'
  end







end
