class SignsController < ApplicationController
add_flash_types :success, :warning, :danger, :info
  def new
    @total = User.all
  	@user = User.find_by(id: params[:id])

  end


  def update
    @id = User.find_by(id: params[:id])
    if (@use= User.update(user_params))
      random = rand(100000..999999)
      @id.update(:otp => random)
      UserMailer.confirm_email(@id).deliver_now
      flash[:success] = "Room Booked check confirmation mail"
      redirect_to "/signs/after_new"
    else
      render 'new'
  end
end


def destroy
  @user = User.find_by(id: params[:id])
  @utp =  params[:otp]
  if @user.otp == @utp.to_i
    @user.destroy
    redirect_to '/signs/afterdelete'
  else
    flash[:danger] ="Wrong OTP"
    redirect_to '/sessions/show/'+@user.id.to_s
  end
  end

  def afterdelete
  end

def ootp_params
  params.require(:ootp).permit(:otp)
    end


def user_params
      params.require(:user).permit(:name, :email, :mobile_no,:date_stay ,:room_num)
    end

end
