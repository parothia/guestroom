class UsersController < ApplicationController
  add_flash_types :success, :warning, :danger, :info
  def index
  	@articles = User.all
@all = User.all
    @all.each do |variable|
      @variable = variable
        if variable.date_stay == nil ||variable.date_stay < Date.today 
          variable.destroy
        end
      end

  end


  


def signin
	@user = User.new
   @date = params[:date]


end

def new

	@user=User.new
  @date = params[:date]
end

def create
  @sign = User.new(user_params)
  @sign.update(date_stay: params[:date])
  if @sign.save
      UserMailer.welcome_email(@sign).deliver_now
        flash[:success] = "Check Booking link in your mail"
        redirect_to '/users/after_signin'
  else
    flash[:warning] = "Please Enter valid details"
    redirect_to '/users/index'
  end



end



private

    def user_params
      params.require(:user).permit(:name, :email, :mobile_no,:date_stay, :room_num)
    end

    def sign_params
      params.require(:hema).permit(:name, :email, :mobile_no)
    end


end

