class AdminsController < ApplicationController
  add_flash_types :success, :warning, :danger, :info
  def index
  end

  
def create

  temp={name: params[:name], password: params[:password]}
  @admin = Admin.find_by(temp)
  if @admin.present?
    @id = alog_in @admin
    redirect_to '/admins/show/'+@id.to_s
  else
    flash[:danger] = "Invalid Name/password Combination"
    redirect_to '/users/index' 
  end
  end

  def show
  	     @all = User.all
  end

  def edit
  @user = User.find_by(id: params[:id])
 # debugger
  end

  def update
  	@user = User.find_by(id: params[:id])
    #debugger
    #render plain: @user.inspect
  	if  Date.today+2 < @user.date_stay
  	if  @user.update_attributes(user_params)
      UserMailer.welcome_email(@user).deliver_now
      flash[:success] = "Admin Updated user booking, mail sent to user"
      redirect_to "/admins/show/"+ session[:admin_id].to_s
    else
      flash[:warning] = "You must obey validations"
      render 'edit'
     end
    else
    	flash[:warning] = "You Cant update time limit is over"
      redirect_to '/admins/show'+session[:admin_id].to_s

  end
end

def newbook
  @user = User.new
end


def newbooking
  @user = User.new(user_params)
  if @user.date_stay!= nil && @user.date_stay >= Date.today 
      if @user.name != nil && @user.email != nil && @user.mobile_no != nil && @user.room_num != nil
            if @user.save
               redirect_to '/admins/show/'+session[:admin_id].to_s
              else
                 flash[:warning] = "Database full"
                render 'newbook'
            end
        else     
          flash[:warning] = "fill are details"
          render 'newbook'
      end
    else
      flash[:warning] = "Enter Correct date of stay"
      render 'newbook'
    end

end


  def user_params
      params.require(:user).permit(:name, :email, :mobile_no,:date_stay ,:room_num)
    end

end
