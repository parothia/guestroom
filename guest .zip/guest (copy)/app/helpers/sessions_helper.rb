module SessionsHelper

# Logs in the given user.
  def log_in(user)
    session[:user_id] = user.id
  end



   # Returns the current logged-in user (if any).
  def current_user
    if session[:user_id]
      @current_user ||= User.find_by(id: session[:user_id])
    end
  end



  # Returns true if the user is logged in, false otherwise.
  def logged_in?
    !current_user.nil?
  end

  # Logs out the current user.
  def log_out
    session.delete(:user_id)
    @current_user = nil
  end







  # Logs in the given admin.

  def alog_in(admin)
    session[:admin_id] = admin.id
  end



   # Returns the current logged-in user (if any).
  def acurrent_admin
    if session[:admin_id]
      @current_admin ||= Admin.find_by(id: session[:admin_id])
    end
  end



  # Returns true if the user is logged in, false otherwise.
  def alogged_in?
    !acurrent_admin.nil?
  end

  # Logs out the current user.
  def alog_out
    session.delete(:admin_id)
    @current_admin = nil
  end





end
